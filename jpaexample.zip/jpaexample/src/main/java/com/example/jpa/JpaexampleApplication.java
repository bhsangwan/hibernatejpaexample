package com.example.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.jpa.enity.Student;
import com.example.jpa.repository.StudentRepository;

@SpringBootApplication
public class JpaexampleApplication implements CommandLineRunner{

	@Autowired
	StudentRepository repo;
	
	public static void main(String[] args) {
		SpringApplication.run(JpaexampleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//Student student = new Student(2, "Harish", "Kumar", "hr@gmail.com", "hr@123", "Delhi");
		//repo.saveOrUpdateStudent(student);
		//Student st = repo.getStudentById(1);
		//System.out.println(st);
		//repo.deleteStudent(52);
	}
}
